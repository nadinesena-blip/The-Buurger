﻿namespace Login
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label = new Label();
            txtLoginNome = new TextBox();
            txtLoginSenha = new TextBox();
            btnLoginEntrar = new Button();
            btnLoginCadastrar = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // Label
            // 
            Label.AutoSize = true;
            Label.Location = new Point(159, 49);
            Label.Name = "Label";
            Label.Size = new Size(37, 15);
            Label.TabIndex = 0;
            Label.Text = "Login";
            // 
            // txtLoginNome
            // 
            txtLoginNome.Location = new Point(126, 84);
            txtLoginNome.Name = "txtLoginNome";
            txtLoginNome.Size = new Size(100, 23);
            txtLoginNome.TabIndex = 1;
            // 
            // txtLoginSenha
            // 
            txtLoginSenha.Location = new Point(126, 124);
            txtLoginSenha.Name = "txtLoginSenha";
            txtLoginSenha.Size = new Size(100, 23);
            txtLoginSenha.TabIndex = 2;
            // 
            // btnLoginEntrar
            // 
            btnLoginEntrar.Location = new Point(143, 164);
            btnLoginEntrar.Name = "btnLoginEntrar";
            btnLoginEntrar.Size = new Size(69, 22);
            btnLoginEntrar.TabIndex = 3;
            btnLoginEntrar.Text = "Entrar";
            btnLoginEntrar.UseVisualStyleBackColor = true;
            btnLoginEntrar.Click += btnLoginEntrar_Click;
            // 
            // btnLoginCadastrar
            // 
            btnLoginCadastrar.Location = new Point(143, 192);
            btnLoginCadastrar.Name = "btnLoginCadastrar";
            btnLoginCadastrar.Size = new Size(69, 22);
            btnLoginCadastrar.TabIndex = 4;
            btnLoginCadastrar.Text = "Cadastrar";
            btnLoginCadastrar.UseVisualStyleBackColor = true;
            btnLoginCadastrar.Click += btnLoginCadastrar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(63, 92);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 5;
            label1.Text = "Nome";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(64, 132);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 6;
            label2.Text = "Senha";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(345, 276);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnLoginCadastrar);
            Controls.Add(btnLoginEntrar);
            Controls.Add(txtLoginSenha);
            Controls.Add(txtLoginNome);
            Controls.Add(Label);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Label;
        private TextBox txtLoginNome;
        private TextBox txtLoginSenha;
        private Button btnLoginEntrar;
        private Button btnLoginCadastrar;
        private Label label1;
        private Label label2;
    }
}
