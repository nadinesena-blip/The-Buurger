namespace Login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLoginCadastrar_Click(object sender, EventArgs e)
        {
            Cadastro telaCadastro = new Cadastro();
            telaCadastro.Show();
            this.Hide();

        }

        private void btnLoginEntrar_Click(object sender, EventArgs e)
        {
            int i;
            bool encontrado = false;
            for (i = 0; i < Repositorio.usuariosCadastro.Count; i++)
            {
                Usuarios u = Repositorio.usuariosCadastro[i];
                if (u.Nome == txtLoginNome.Text && u.Senha == txtLoginSenha.Text)
                {
                    encontrado = true;
                    break;
                }
            }
            if (encontrado == true)
            {
                MessageBox.Show("Voc� acessou!");
            }
            else
            {
                MessageBox.Show("Voc� n�o est� cadastrado no sistema.");
            }
        }
    }
}
