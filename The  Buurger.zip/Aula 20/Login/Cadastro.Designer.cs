﻿namespace Login
{
    partial class Cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtCadastroNome = new TextBox();
            txtCadastroSenha = new TextBox();
            btnCadastroCadastrar = new Button();
            btnCadastroLogin = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(157, 47);
            label1.Name = "label1";
            label1.Size = new Size(54, 15);
            label1.TabIndex = 0;
            label1.Text = "Cadastro";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(69, 86);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 1;
            label2.Text = "Nome";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(70, 124);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 2;
            label3.Text = "Senha";
            // 
            // txtCadastroNome
            // 
            txtCadastroNome.Location = new Point(141, 86);
            txtCadastroNome.Name = "txtCadastroNome";
            txtCadastroNome.Size = new Size(100, 23);
            txtCadastroNome.TabIndex = 3;
            // 
            // txtCadastroSenha
            // 
            txtCadastroSenha.Location = new Point(141, 124);
            txtCadastroSenha.Name = "txtCadastroSenha";
            txtCadastroSenha.Size = new Size(100, 23);
            txtCadastroSenha.TabIndex = 4;
            // 
            // btnCadastroCadastrar
            // 
            btnCadastroCadastrar.Location = new Point(157, 169);
            btnCadastroCadastrar.Name = "btnCadastroCadastrar";
            btnCadastroCadastrar.Size = new Size(75, 23);
            btnCadastroCadastrar.TabIndex = 5;
            btnCadastroCadastrar.Text = "Cadastrar";
            btnCadastroCadastrar.UseVisualStyleBackColor = true;
            btnCadastroCadastrar.Click += btnCadastroCadastrar_Click;
            // 
            // btnCadastroLogin
            // 
            btnCadastroLogin.Location = new Point(157, 198);
            btnCadastroLogin.Name = "btnCadastroLogin";
            btnCadastroLogin.Size = new Size(75, 23);
            btnCadastroLogin.TabIndex = 6;
            btnCadastroLogin.Text = "Login";
            btnCadastroLogin.UseVisualStyleBackColor = true;
            btnCadastroLogin.Click += btnCadastroLogin_Click;
            // 
            // Cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(361, 295);
            Controls.Add(btnCadastroLogin);
            Controls.Add(btnCadastroCadastrar);
            Controls.Add(txtCadastroSenha);
            Controls.Add(txtCadastroNome);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Cadastro";
            Text = "Cadastro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtCadastroNome;
        private TextBox txtCadastroSenha;
        private Button btnCadastroCadastrar;
        private Button btnCadastroLogin;
    }
}