﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();
        }

        private void btnCadastroLogin_Click(object sender, EventArgs e)
        {
            Form1 telaLogin = new Form1();
            telaLogin.Show();
            this.Close();
        }

        private void btnCadastroCadastrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCadastroNome.Text) ||
                string.IsNullOrWhiteSpace(txtCadastroSenha.Text)) 
            {
                MessageBox.Show("Por gentileza, não coloque espaços e não deixe os campos vazios");
                return;
            }
            Usuarios novoUsuario = new Usuarios();
            novoUsuario.Nome = txtCadastroNome.Text;
            novoUsuario.Senha = txtCadastroSenha.Text;

            Repositorio.usuariosCadastro.Add(novoUsuario);
            MessageBox.Show("Usuário cadastrado com sucesso!");
        }
    }
}
