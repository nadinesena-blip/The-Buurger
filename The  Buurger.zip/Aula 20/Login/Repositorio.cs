﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login
{
    internal class Repositorio
    {
        public static List<Usuarios> usuariosCadastro = new List<Usuarios>();

    }
}
